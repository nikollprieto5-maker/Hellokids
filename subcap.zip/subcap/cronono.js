const idiomaActual = document.getElementById('idioma');
const ListaIdioma = document.getElementById('idiomas');
const idiomas = document.getElementsByClassName('opcion');

idiomaActual.addEventListener('click', () => {
  ListaIdioma.classList.toggle('toggle');
});

Array.from(idiomas).forEach((opcion) => {
  opcion.addEventListener('click', () => {
    const idioma = opcion.querySelector('span').textContent.toLowerCase();
    establecerIdiomaCrono(idioma);
  });
});

function establecerIdiomaCrono(idioma) {
  idiomaActual.querySelector('img').src = `banderas/${idioma}.svg`;

  const titulo = document.getElementById('titulo-crono');
  const bienvenida = document.getElementById('bienvenida-crono');
  const desc1 = document.getElementById('desc1-crono');
  const desc2 = document.getElementById('desc2-crono');
  const footer = document.getElementById('footer-crono');

  const inicio = document.getElementById('inicio-crono');
  const quienes = document.getElementById('quienes-crono');
  const intro = document.getElementById('intro-crono');
  const logo = document.getElementById('logo-crono');
  const objetivos = document.getElementById('objetivos-crono');
  const obj1 = document.getElementById('obj1-crono');
  const obj2 = document.getElementById('obj2-crono');
  const objg = document.getElementById('objg-crono');
  const contacto = document.getElementById('contacto-crono');

  if (idioma === 'usa') {
    titulo.textContent = 'HELLO KIDS!!';
    bienvenida.textContent = 'Welcome to our website kids!';
    desc1.textContent = 'Through this schedule, you will be able to find out about the activities we carry out throughout our project. We require time and space from teachers and students to carry out the activities.';
    desc2.textContent = 'I hope you understand and like our plan.';
    footer.innerHTML = 'Author: Sharon Prieto, Angie Perlaza<br><a href="mailto:nikollprieto5@gmail.com">nikollprieto5@gmail.com</a><br><a href="mailto:perlazaangiemarcela@gmail.com">perlazaangiemarcela@gmail.com</a><br>&copy;Sharon Prieto <br> Angie Perlaza| 2025';

    inicio.textContent = 'HOME PAGE';
    quienes.textContent = 'ABOUT US';
    intro.textContent = 'INTRODUCTION';
    logo.textContent = 'Our Logo';
    objetivos.textContent = 'OBJECTIVES';
    obj1.textContent = 'Specific Objective';
    obj2.textContent = 'Specific Objective 2';
    objg.textContent = 'General Objective';
    contacto.textContent = 'CONTACT';
  } else {
    titulo.textContent = '¡HOLA NIÑOS!';
    bienvenida.textContent = '¡Bienvenidos a nuestro sitio web niños!';
    desc1.textContent = 'A través de este cronograma, podrás conocer las actividades que realizamos a lo largo de nuestro proyecto. Requerimos tiempo y espacio de los profesores y estudiantes para llevar a cabo las actividades.';
    desc2.textContent = 'Espero que entiendas y te guste nuestro plan.';
    footer.innerHTML = 'Autor: Sharon Prieto, Angie Perlaza<br><a href="mailto:nikollprieto5@gmail.com">nikollprieto5@gmail.com</a><br><a href="mailto:perlazaangiemarcela@gmail.com">perlazaangiemarcela@gmail.com</a><br>&copy;Sharon Prieto <br> Angie Perlaza| 2025';

    inicio.textContent = 'PÁGINA DE INICIO';
    quienes.textContent = 'QUIENES SOMOS';
    intro.textContent = 'INTRODUCCIÓN';
    logo.textContent = 'Nuestro logo';
    objetivos.textContent = 'OBJETIVOS';
    obj1.textContent = 'Objetivo específico';
    obj2.textContent = 'Objetivo específico 2';
    objg.textContent = 'Objetivo general';
    contacto.textContent = 'CONTACTO';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const lang = navigator.language;
  establecerIdiomaCrono(lang === 'en-US' ? 'latino' : 'usa');
});