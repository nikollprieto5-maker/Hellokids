const idiomaActual = document.getElementById('idioma');
const ListaIdioma = document.getElementById('idiomas');
const idiomas = document.getElementsByClassName('opcion');

idiomaActual.addEventListener('click', () => {
  ListaIdioma.classList.toggle('toggle');
});

Array.from(idiomas).forEach((opcion) => {
  opcion.addEventListener('click', () => {
    const idioma = opcion.querySelector('span').textContent.toLowerCase();
    establecerIdiomaQuienes(idioma);
  });
});

function establecerIdiomaQuienes(idioma) {
  idiomaActual.querySelector('img').src = `banderas/${idioma}.svg`;

  const titulo = document.getElementById('titulo-qn');
  const bienvenida = document.getElementById('bienvenida-qn');
  const texto1 = document.getElementById('texto-qn1');
  const texto2 = document.getElementById('texto-qn2');
  const footer = document.getElementById('footer-qn');

  const inicio = document.getElementById('inicio-qn');
  const quienes = document.getElementById('quienes-qn');
  const intro = document.getElementById('intro-qn');
  const logo = document.getElementById('logo-qn');
  const cronograma = document.getElementById('cronograma-qn');
  const actividades = document.getElementById('actividades-qn');
  const actCrono = document.getElementById('act-crono-qn');
  const actLogo = document.getElementById('act-logo-qn');
  const contacto = document.getElementById('contacto-qn');

  const objetivoGeneral = document.getElementById('ObjetivoGeneral');
  const objetivosEspecificos = document.getElementById('ObjetivosEspecificos');
  const Mision = document.getElementById('Mision');
  const Vision = document.getElementById('Vision');

  if (idioma === 'usa') {
    titulo.textContent = 'HELLO KIDS!!';
    bienvenida.textContent = 'Welcome to our website kids!';
    texto1.textContent = 'In this section, you can see what our mission or purpose will be throughout the implementation of the website, application, and game that we will be applying.';
    texto2.textContent = 'We want you to learn, explore, and have fun while discovering new things!';
    footer.textContent = '© Sharon Prieto | Angie Perlaza | 2025';

    inicio.textContent = 'HOME PAGE';
    quienes.textContent = 'ABOUT US';
    intro.textContent = 'INTRODUCTION';
    logo.textContent = 'Our Logo';
    cronograma.textContent = 'Schedule';
    actividades.textContent = 'ACTIVITIES';
    actCrono.textContent = 'Schedule';
    actLogo.textContent = 'Our Logo';
    contacto.textContent = 'CONTACT';
    objetivoGeneral.innerHTML = 'GENERAL OBJECTIVE ';
    objetivosEspecificos.innerHTML = 'SPECIFIC OBJECTIVES ';
    Mision.innerHTML = 'MISSION ';
    Vision.innerHTML = 'VISION ';
  } else {
    titulo.textContent = '¡HOLA NIÑOS!';
    bienvenida.textContent = '¡Bienvenidos a nuestra página!';
    texto1.textContent = 'En esta sección podrás ver cuál será nuestra misión o propósito durante la implementación de la página web, aplicación y juego que estaremos aplicando.';
    texto2.textContent = '¡Queremos que aprendas, explores y te diviertas mientras descubres cosas nuevas!';
    footer.textContent = '© Sharon Prieto | Angie Perlaza | 2025';

    inicio.textContent = 'PÁGINA DE INICIO';
    quienes.textContent = 'QUIENES SOMOS';
    intro.textContent = 'INTRODUCCIÓN';
    logo.textContent = 'Nuestro logo';
    cronograma.textContent = 'Cronograma';
    actividades.textContent = 'ACTIVIDADES';
    actCrono.textContent = 'Cronograma';
    actLogo.textContent = 'Nuestro Logo';
    contacto.textContent = 'CONTACTO';

    objetivoGeneral.innerHTML = 'OBJETIVO GENERAL ';
    objetivosEspecificos.innerHTML = 'OBJETIVOS ESPECIFICOS ';
    Mision.innerHTML = 'MISION ';
    Vision.innerHTML = 'VISION ';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const lang = navigator.language;
  establecerIdiomaQuienes(lang === 'en-US' ? 'latino' : 'usa');
});
    function mostrarImagen(num) {
      let imgs = document.querySelectorAll(".imagenes img");
      imgs.forEach(img => img.style.display = "none");
      if(num > 0) document.getElementById("img" + num).style.display = "block";
    }